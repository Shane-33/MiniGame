# blackjack-python-practice
python练习：单机简陋21点小游戏

规则：
无庄家、无筹码、A算1分
